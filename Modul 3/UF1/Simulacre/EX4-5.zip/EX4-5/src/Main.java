//Problema 1

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //DECLARACIÓ E INICIALITZACIÓ DE VARIABLES
        int a = 0;

        class Conversor {
            public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);

                //DECLARACIÓ E INICIALITZACIÓ DE VARIABLES
                double euro = 0.0;
                int opció = 0;

                System.out.println("1.Euro a Dolàr americà");
                System.out.println("2.Euro a Lliures Esterlines");
                System.out.println("3.Sortir");

                System.out.println("Què vols calcular?");
                opció = scanner.nextInt();

                switch (opció) {
                    case 1: //Euro a dolars americans
                        System.out.println("Has triat la opció 1");
                        System.out.println("Introdueix la quantitat €");
                        double eurodolar = 0.97;
                        double dolar = euros * eurodolar;
                        System.out.println("El canvi és:"dolar);
                        moneda_intr = scanner.nextDouble();
                        break;

                    case 2: //Euro a lliures esterlines
                        System.out.println("Has triat la opció 2");
                        System.out.println("Introdueix la quantitat" + euro + "€");
                        double eurodolar = 0.97;
                        double libra = euros * libra;
                        System.out.println("El canvi és:"libra);
                        moneda_intr = scanner.nextDouble();
                        break;

                    case 3: //Sortir
                        System.out.println("Has triat sortir del programa.");
                        break;
                }
            }
        }

        scanner.close();
    }
}